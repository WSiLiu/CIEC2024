%% 1

clear all;clc;
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();

T0 = 100;
bottomgray = 0.2;
sti_size = 20;
T = T0;
stimulus0 = 1:2;
N_cue = 1;
noisy_stren = 20;
brightnessconstrast(bottomgray,sti_size,2);


T = T0;
stimulus = stimulus0;

clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns1(stimulus,noisy_stren,T/2,N_cue);

state = 'movement';
num_bio_neurons = 400;
num_train_sets = 200;
num_trials0 = 500;

tic;

[ex_path1,patterns] = do_learning_task_stereomovement1( 'results/', ...
                  pat_sequences, ... 
                  default_params{:}, ...
                  'pattern_length', size(patterns{1,1},2),...
                  'free_run_seqs',  free_pat_sequences , ... 
                  'pat_labels', pat_labels, ...
                  'free_run_pat_lenghts', size(patterns{1, 1},2), ...
                  'num_bio_neurons', num_bio_neurons, ...             % number of WTA neurons
                  'num_inputs', num_inputs, ...              % number of afferent neurons
                  'free_run_time', size(patterns{1,1},2), ...         % free run time (s)
                  'save_interval', (num_train_sets-1), ...           % number of iterations between 2 save files
                  'num_train_sets', num_train_sets, ...        % number of training iterations
                  'collect', '[At,R]', ...
                  'num_epochs', 1, ...
                  'patterns', patterns, ...
                  'sample_method', 'brightness', ...
                  'state',state, ...
                  'T', T, ...
                  'stimulus', stimulus, ...
                  'N_cue',N_cue,...
                  'cue', cue, ...
                  'noisy_stren', noisy_stren, ...
                  'changelog_flag', 'N' );
toc;
ex_path_brightness = ex_path1;
% save('ex_path_brightness','ex_path_brightness');

% ex_path1 = load('ex_path_brightness');ex_path1 = ex_path1.ex_path_brightness
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
state = 'movement';

stimulus = stimulus0;
num_trials = num_trials0;
clear patterns;
clear pat_labels;
clear pat_sequences;
clear free_pat_sequences;
[patterns,pat_sequences,free_pat_sequences,pat_labels,num_inputs,cue] = generate_patterns_test1(stimulus,noisy_stren,T/2,N_cue);

eval_mem_task_steremovement1(ex_path1,num_trials,state,T,stimulus,noisy_stren,N_cue,cue);
name1 = ['data_set_00000',num2str(num_train_sets-1),'.mat'];% 需确认data_set文件名中'0'的个数。
src_file_name1 = [ex_path1,name1];
name2 = ['mem_task_test',num2str(num_trials),'.mat'];
src_file_name2 = [ex_path1,name2];
eval_mem_task_steremovement1_1( ex_path1,num_trials,state,T,stimulus,src_file_name1,src_file_name2 )

path = [ex_path1,'mem_task_test',num2str(num_trials),'.mat'];
load(path);
brightnessperception(ex_path1,path,num_trials,T,stimulus,bottomgray,sti_size);

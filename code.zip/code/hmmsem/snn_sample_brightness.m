function [net,Z,P] = snn_sample_brightness( net, data, ct )
net.update_on_spike =1;
t = data.time(ct(1));
time_range = (data.time(ct(end))-data.time(ct(1)));
num_spikes = max(floor(time_range*1000),size(net.patterns{1,1},2));
spike_times = (1:num_spikes)/1000;
net.w_rf = -5;
net.tau_rf = 0.01;
net.num_neurons = net.num_bio_neurons;
count = [0;0];
count1 = [0;0];
iden_t = (net.T/2)*ones(size(net.iden_t,1)+1,1);

    Z_spikes = inf(net.num_bio_neurons,num_spikes);%
    a_Z = zeros(net.num_bio_neurons,1);
    
    aZ = zeros(net.num_bio_neurons,1);
    Z = zeros(net.num_bio_neurons, num_spikes, 'single');
    
    last_spikes_X = repmat(t, net.num_inputs, 1);
    last_spikes_Z = repmat(t, net.num_bio_neurons, 1);
    
    hX = zeros(net.num_inputs,2);
    hZ = zeros(net.num_bio_neurons,2);
    
    net.d_W = zeros(net.num_bio_neurons,net.num_inputs);
    net.d_V =  zeros(net.num_bio_neurons,net.num_bio_neurons);
    net.d_V0 = zeros(net.num_bio_neurons,1);
    
    P = zeros(net.num_bio_neurons, 1, 'single');
    net.At = zeros(2,num_spikes, 'single');
    A_v = zeros(1,num_spikes);
    A_w = zeros(1,num_spikes);
    
    i = 1;
    i_Z = 1;
    
    action = 0;
    reward = 0;

     if ~isfield( net, 'groups' )
         net.groups = 0;
     end
     if ~isfield( net, 'alpha_w' )
         net.alpha_w = 1;
     end
    if ~isfield( net, 'alpha_v' )
        net.alpha_v = 1;
    end
    if ~isfield( net, 'w_temperature' )
        net.w_temperature = 1;
    end
    
    group_idx = [ 0, cumsum( net.groups ), net.num_bio_neurons ]; 
    net.num_o(:) = 0;
    %%
    try
       for j = 1:num_spikes
           j0 = floor(j/(net.T));
           j1 = j-(j0*net.T);
           t = spike_times(j);
          %%
           % update feedforward synapses
            while (i < size(data.Xt,2)) && (t > data.Xt(2,i))
                 n_id = data.Xt(1,i);
                 spiking_t = data.Xt(2,i);
                
                 hX(n_id,1) = hX(n_id,1)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_r) + 1;
                 hX(n_id,2) = hX(n_id,2)*exp(-double(spiking_t-last_spikes_X(n_id))/net.tau_x_f) + 1;
                 last_spikes_X(n_id) = spiking_t;
                 i = i+1;
             end
             

            %% 计算神经元的突触后电流output trace
            
             hX(:,1) = hX(:,1).*exp(-double(t-last_spikes_X)/net.tau_x_r);
             hX(:,2) = hX(:,2).*exp(-double(t-last_spikes_X)/net.tau_x_f);
             d_hX = diff(hX,1,2);
             hX_all(:,j) = d_hX;
             if (j1 == 0)&&(j>net.T)
                 hX = zeros(net.num_inputs,2);   
                 hZ = zeros(net.num_bio_neurons,2);
                 last_spikes_Z(:) = t;
                 
             end
             
            %% 确定可塑性的网络兴奋连接
             net.W = min(1,max(0.00001,net.W));
             
            %% update membrane potential and draw spikes
             t1 = (j0*net.T)-net.T*double(j==(j0*net.T))+1;
             [j,t1];
             
             
             % update bio ex membrane potential and draw spikes
             UZ_ei = zeros(net.num_bio_neurons,1);
             UZ_ee = net.W*d_hX;
             %UZ = UZ_ee + UZ_ei;
             UZ = UZ_ee + UZ_ei;
             PZ = zeros(net.num_bio_neurons,1);
             [PZ_t,AZ_t] = wta_softmax2( UZ );
             
             PZ(:,j) = PZ_t;
             [Z_j,K] = wta_draw_k2(PZ_t,Z,j);
             clear aa;
             aa = sum(Z(:,max(j1,j-net.ex_delay):j),2);
             Z_j(:) = Z_j(:).*double(aa == 0);
             Z(:,j) =Z_j(:);Z_spikes(:,j) = Z_j(:);
             a_Z = a_Z + Z_j(:);

             if (~isempty(K))
                 for n_k = 1:size(K,1)
                     k1 = K(n_k);
                     if Z_j(k1) == 1
                     last_spikes_Z(k1) = t;
                     end
                 end
             end
             
            %% Update clustering sets
             j0 = floor(j/(net.T));j1 = j-(j0*net.T);
             if (j1<net.t_start)&&(j>(j0*(net.T)))
                   action = 0;reward = 0;
             end
             if j1 == (net.T)/2
                 action = 0;reward = 0;iden_t0 = 0;
             end
             if ((j > net.T)&&(j > (j0*(net.T)))&&(j1 >= net.t_start))||(j == num_spikes)
              % ((j > net.T)&&(j > (j0*(net.T)))&&(j1 >= net.t_start)&&(j0 <= size(net.action,2)+1))||(j == num_spikes)
                 [j j1 ceil(j/(net.T)) j0*(net.T) size(net.action,2)+1 1];
                 observe_size = 1;
                 clear observe;
                 observe = Z(:,j+1-observe_size:j);
                 observe = observe(:,find(sum(observe)>0));

               %% Update merged clustering sets
                 for ii = 1:2
                  for jj = 1:net.N_cue
                  if (sum(sum(net.action{jj,ii}))==0)
                     net.n_clu_merged(jj,ii) = ii;
                  end
                  end
                 end
                 
                 if (j1<(net.t_start))&&(j0<=size(net.action,2)+1)
                 for ii = 1:size(net.n_clu_merged,2)%在最�?��先判断被融合的集合是哪个，之后对于每个刺�?��都将�?��始的观测活动加入这个集合�?
                  for jj = 1:net.N_cue
                  
                  if (net.n_clu_merged(jj,ii) == ii)&&(~isempty(observe))
                      net.action{jj,ii} = [net.action{jj,ii},observe];
                      net.action{jj,ii} = net.action{jj,ii}(:,find(sum(net.action{jj,ii})>0));
                      if size(net.action{jj,ii},2)>net.cluster_size
                         net.action{jj,ii} = net.action{jj,ii}(:,end-net.cluster_size+1:end);
                      end
                  end
                  if  (j0==size(net.action,2)+1)&&(j1==(net.t_start)+3)
                      net.n_clu_merged(1,n_clu) = 0;
                  end
                 end
                 end
                 end
               %% likelihoods for identification
                 N_cue = net.N_cue;
                 if (~isempty(observe))&&(j1>=net.T/2)&&(net.cue(1,ceil(j/(net.T)))>0)%活动不为空�?刺激出现、线索出现时，才进行判断
                    % likelihoods and actions
                    
                    if reward == 0 % 每次模拟中，出现刺激的组数不重要，对于每组刺�?��判断每对刺激是否同源才是关键�?
                     p = zeros(N_cue,2);%对于每一组刺�?��计算各个源头同源的概率�?
                     [p,p1] = probability_equaldistribution_clustering1(observe,net.action,p,net.significance,net.Repeat,net.N_cue);
                     % 对于每一个源头，判断刺激是否同源的概率�?
                     for nn = 1:N_cue
                         clear aa1;clear aa2;
                         aa1 = p(nn,:);
                         action(1,nn) =  find(aa1 == max(aa1),1);%action(1,nn)表示对于刺激是否同源于第nn个源头�?
                     end
                     clear c;clear c0;c = 1;
                     
                     for nn = 1:N_cue
                         
                         c = c * double(action(nn) == net.cue(nn,ceil(j/(net.T))));
                         
%                          [ceil(j/(net.T))  net.cue(nn,ceil(j/(net.T))) action(nn) j1 c]
%                          pause(1)
                     end
                    
                     reward = c;
                     
                     if (reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)
                         iden_t0 = max(1,j1-(net.T)/2);%记录了正确判断的时刻
                         iden_t(ceil(j/(net.T))) = iden_t0;
                         [j j1 iden_t0]
                         
                     end
                    end
                    for mm = 1:net.N_cue
                    count1(mm,1) = count1(mm,1) + 1;
                    count(mm,1) = count(mm,1) + reward;
                    end
                     
                 end
            %% update the clustering set
              if (action ~= 0)&&(reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)
                   
                         sample = observe;
                         for nn1 = 1:net.N_cue
                             net.action{nn1,action(nn1)} = [net.action{nn1,action(nn1)},sample];
                             net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,find(sum(net.action{nn1,action(nn1)})>0));
                             if size(net.action{nn1,action(nn1)},2)>net.cluster_size
                                 net.action{nn1,action(nn1)} = net.action{nn1,action(nn1)}(:,end-net.cluster_size+1:end);          
                             end 
                         end
      
                     
              end
 
            %% synaptic weight updates (STDP)
            
             %reward = 1;
             if (j~=num_spikes)&&(reward == 1)&&(net.cue(1,ceil(j/(net.T)))>0)
              
              eta = net.eta;
              net.W = min(1,max(0.00001,net.W));
              
              for n_k = 1:size(Z,1)
                    clear d_W_k1;clear d_W_k2;clear W_d;
                    d_W_k1 = Z(n_k,1);
                    d_W_k2 = d_hX(:,1)';
                    W_d = exp(-net.W(n_k,:));
                    d_W_k = d_W_k1*(d_W_k2.*W_d)-1;
                    net.W(n_k,:) = net.W(n_k,:) + eta*d_W_k;
                    net.W(n_k,:) = min(1,max(0.00001,net.W(n_k,:)));
              end
             end
              
             if (j1 <= 1)&&(j>net.T)
                 [j,j1];
                 hX = zeros(net.num_inputs,2);   
                 hZ = zeros(net.num_bio_neurons,2);    
                 d_hX = diff(hX,1,2);
                 last_spikes_Z(:) = t;
             end
             
             end
       end
        
        
        
        
    catch
           fprintf('There has been an error, while sampling!\nExcluding run from training\n');
           file_name = sprintf('/tmp/error_data_%u_%04u.mat', net.iteration, round(9999*rand()) );
           the_error = lasterror();
           fprintf( '\n%s\n', the_error.message );
           fprintf( '  in %s on line %i\n\n', the_error.stack(1).name, the_error.stack(end).line );
           fprintf('saving workspace to: %s\n', file_name);
           save( file_name );
           
           net.R = -100000;
           fprintf('pausing 10 seconds...\n');
           pause(1);
           return;
    end
    
    
    net.Z_spikes = Z_spikes(:,i_Z:end);
    net.R = mean( net.At(1,:) );
    net.A_v = A_v;
    net.A_w = A_w;
    
    net.hX = hX;
    net.hZ = hZ;
    
    net.spike_train = Z;
    count = count(1:net.N_cue,1);
    count1 = count1(1:net.N_cue,1);
    net.count = [net.count,count];
    net.total_count = [net.total_count,count1];
    [count;count./count1];
    clear iden_t3;
    iden_t3 = (iden_t(:))';
    size(iden_t(:));
    size(net.iden_t);
    net.iden_t = [net.iden_t,iden_t(2:end)];
    
%%
end
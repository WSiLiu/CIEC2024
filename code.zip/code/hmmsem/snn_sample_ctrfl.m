function [net,Z,P] = snn_sample_ctrfl( net, data, ct )
% Draws a spike from sem network - continuous time spiking hmm sems realistic refractory mechanim.
%
% [net,Z,P] = snn_sample_ctrfl( net, data, ct )
%
% Generates the output of a given wta-network by drawing
% a winner neuron from the current output probabilities
% (standard version).
%
% inputs:
%   net:  A wta-network, see: wta-new()
%   data: A data structure to be simulated.
%   ct:   Current time index.
%
% output:
%   net:      The (modified) network structure
%   Z:        Network output spikes
%
% @parameters:
%   tau_x_r                0.002      time constant of epsp window rise
%   tau_z_r                0.002      time constant of epsp window rise
%   tau_x_f                0.02       time constant of epsp window fall
%   tau_z_f                0.02       time constant of epsp window fall
%   tau_rf                 0.005      time constant of refractory window
%   w_rf                   -10        strength of refractory window
%   lambda                 2000       network spike rate
%   mean_rec_delay         0.010      mean delay on recurrent synapses
%   groups                 0          assignment of neurons to groups
%   std_rec_delay          0.000      standard deviation of recurrent delay
%   temperature            1          sampling temperature
%   iw_mode                'exact'    method to calculate importance weights
%   use_variance_tracking  false      use variance tracking for learn rates
%   update_on_spike        false      update weights when spike occurs
%   fix_num_spikes         false      fix number of output spikes
%   alpha_w                1          ff balance between exc. and dep.
%   alpha_v                1          lat balance between exc. and dep.
%   w_temperature          1          weight factor between ff/lat. inputs
%
% @fields:
%   rec_delay     randn[mean_rec_delay,std_rec_delay]  [num_neurons,1]
%   rec_spikes    zeros [0,0]              recurrent spike events
%   last_spike_t  zeros  [num_neurons,1]   last output spike times
%   At    szeros  [2,0]             log activity of network at spike times
%   A_w   zeros   [2,0]             log activity at feedforward synapses at spike times
%   A_v   zeros   [2,0]             log activity at recurrent synapses at spike times
%   It    zeros   [0,0]             inhibitory current at spike times
%   hX    zeros   [num_inputs,2]    feedforward PSPs
%   hZ    zeros   [num_neurons,2]   recurrent PSPs
%   R     zeros   [1,1]             current importance weight (log)
%   num_o zeros   [num_neurons,1]   number of output spikes per neuron
%   eta_W const[eta] [num_neurons,num_inputs]
%   eta_V const[eta] [num_neurons,num_neurons]
%   eta_0 const[eta] [num_neurons,1]
%   SW    zeros      [num_neurons,num_inputs]
%   QW    ones       [num_neurons,num_inputs]
%   SV    zeros      [num_neurons,num_neurons]
%   QV    ones       [num_neurons,num_neurons]
%   S0    zeros      [num_neurons,1]
%   V0    ones       [num_neurons,1]
%
%
% David Kappel
% 24.05.2011
%
%
%%%%%parameters
%     clear all;clc;
%     data.time = 1:10000;%
%     ct = 1:10000;%
%     eta = 0.005;
%     net.groups = 0;
%     net.num_neurons = 100;%
%     num_neurons = 100;
%     net.num_inputs = 400;%
%     num_inputs = 400;%
%     net.alpha_w = 1;
%     net.alpha_v = 1;
%     net.w_temperature = 1;
%     net.tau_z_r = 0.002;net.tau_x_r = 0.002;
%     net.tau_z_f = 0.02;net.tau_x_f = 0.02;

%     net.eta_W = eta*ones(num_neurons,num_inputs);
%     net.eta_V = eta*ones(num_neurons,num_neurons);
%     net.eta_V0 = eta*ones(num_neurons,1);
%     net.W = rand(net.num_neurons,net.num_inputs);
%     net.V = rand(net.num_neurons,net.num_neurons);
%     net.V0 = rand(net.num_neurons,1);
%     net.num_o = zeros(net.num_neurons,1);
    net.update_on_spike =1;
    
%     data.Xt = zeros(2,size(data.time,2));
%     data.Xt(1,:) = ceil(num_inputs*rand(1,size(data.time,2)));
%     data.Xt(2,:) = data.time;
%%%%%%%%%%%%%
    t = data.time(ct(1));
%     data
%     pause;
%     net
%     pause;
    %time_range = size(net.spike_train,2)/1000;
%     data.time
    time_range = (data.time(ct(end))-data.time(ct(1)));%ȷ��ʱ�䳤��Ϊtime_range
%     time_range
%     6
%     pause;
%     size(net.patterns{1,1},2)
%     pause;
%     num_spikes = floor(time_range*1000);
    num_spikes = max(floor(time_range*1000),size(net.patterns{1,1},2));
%     size(net.patterns,2)
    num_spikes;
    spike_times = (1:num_spikes)/1000;
    net.w_rf = -5;
    net.tau_rf = 0.01;
    %data.time(ct(1)):data.time(ct(end));
%     if net.fix_num_spikes
%         num_spikes = round( net.lambda*time_range );
%     else
%         num_spikes = poissrnd( double( net.lambda*time_range ) );
%     end
    
%    spike_times = sort( time_range*rand( 1, num_spikes ) );
    rec_spikes = inf(net.num_neurons,num_spikes);%
    inhi_spikes = inf(net.num_inneurons,num_spikes);%
    %num_rec_spikes = size(rec_spikes,2);%
    
    Z = zeros(net.num_neurons, num_spikes, 'single');
    P = zeros(net.num_neurons, 1, 'single');
    net.At = zeros(2,num_spikes, 'single');
    
    last_input_spikes = repmat(t, net.num_inputs, 1);
    last_output_spikes = repmat(t, net.num_neurons, 1);
    last_inhi_spikes = repmat(t, net.num_inneurons, 1);
    
%     last_input_spikes = zeros(net.num_inputs, 1);
%     last_output_spikes = zeros(net.num_neurons, 1);
%     last_inhi_spikes = zeros(net.num_inneurons, 1);
    
%     hX = net.hX;
%     hZ = net.hZ;
    
    hX = zeros(net.num_inputs,2);
    hZ = zeros(net.num_neurons,2);
    hl = zeros(net.num_inneurons,2);     
    
%     W_exp = exp(double( net.W ) );
%     V_exp = exp(double( net.V ) );
%     V0_exp = exp(double( net.V0 ) );
%     W_exp(k,:) = exp( double( net.W(k,:) ) );
%     V_exp(k,:) = exp( double( net.V(k,:) ) );
%     V0_exp = exp( double( net.V0 ) );

    net.d_W =  zeros(net.num_neurons,net.num_inputs);
    net.d_V =  zeros(net.num_neurons,net.num_neurons);
    net.d_V0 = zeros(net.num_neurons,1);
    
    i = 1;
    l = 1;
    k= 1;
    a = 0;
    
    hX_all = zeros(net.num_inputs,num_spikes);
    hZ_all = zeros(net.num_neurons,num_spikes);
    hl_all = zeros(net.num_inneurons,num_spikes);
    A_v = zeros(1,num_spikes);
    A_w = zeros(1,num_spikes);
    
    synaptic_peak = 1.435;

     if ~isfield( net, 'groups' )
         net.groups = 0;
     end
     if ~isfield( net, 'alpha_w' )
         net.alpha_w = 1;
     end
    if ~isfield( net, 'alpha_v' )
        net.alpha_v = 1;
    end
    if ~isfield( net, 'w_temperature' )
        net.w_temperature = 1;
    end
    
    group_idx = [ 0, cumsum( net.groups ), net.num_neurons ];
   
%     if net.use_variance_tracking
%         
%         SW_new = net.SW;
%         QW_new = net.QW;
% 
%         SV_new = net.SV;
%         QV_new = net.QV;
% 
%         S0_new = net.S0;
%         Q0_new = net.Q0;
%         
%         net.eta_W = net.eta*(QW_new-SW_new.^2)./(exp(-SW_new)+1);
%         net.eta_V = net.eta*(QV_new-SV_new.^2)./(exp(-SV_new)+1);
%         net.eta_0 = net.eta*(Q0_new-S0_new.^2)./(exp(-S0_new)+1);
%     end

%     use_exact_iw = strcmp( net.iw_mode, 'exact' );
%     do_assertions = snn_options('assert');
    
    net.num_o(:) = 0;
        
     try        
         for j = 1:num_spikes%num_spikes%��ÿһ�������������۴˿̵�Ĥ��λ�ͷŵ���
             
             t = spike_times(j);
             % update feedforward synapses
             % ����ָ�������Ŀɼ��ԣ�i����Ҫ��ͷ���㣬ֻҪ����ʱ����㼴�ɡ�
             while (i < size(data.Xt,2)) && (t > data.Xt(2,i))
                 n_id = data.Xt(1,i);
                 spiking_t = data.Xt(2,i);
                %����ָ�������Ŀɼ��ԣ��ó˻�����ʽ������EPSP������ָ������
                 hX(n_id,1) = hX(n_id,1)*exp(-double(spiking_t-last_input_spikes(n_id))/net.tau_x_r) + 1;
                 hX(n_id,2) = hX(n_id,2)*exp(-double(spiking_t-last_input_spikes(n_id))/net.tau_x_f) + 1;
                 last_input_spikes(n_id) = spiking_t;
                 i = i+1;
             end
             % update lateral synapses
             while (l < size(rec_spikes,2)) && (t > l/1000 )%l ��ʱ��
                 %l ʱ�̵�����
                 spiking_t = l/1000;
                 for n_id = 1:net.num_neurons
                     if rec_spikes(n_id,l) == 1
                        hZ(n_id,1) = hZ(n_id,1)*exp(-double(spiking_t-last_output_spikes(n_id))/net.tau_z_r) + 1;
                        hZ(n_id,2) = hZ(n_id,2)*exp(-double(spiking_t-last_output_spikes(n_id))/net.tau_z_f) + 1;
                        last_output_spikes(n_id) = spiking_t;
                     end
                 end
                 l = l+1;
             end
             
             % update inhibited lateral synapses
             while (k<size(inhi_spikes,2)) && (t > k/1000)
                 inhi_spiking_t = k/1000;
                 for n_id = 1:net.num_inneurons
                     if inhi_spikes(n_id,k) == 1
                        hl(n_id,1) = hl(n_id,1)*exp(-double(inhi_spiking_t -last_inhi_spikes(n_id))/net.tau_z_r) + 1;
                        hl(n_id,2) = hl(n_id,2)*exp(-double(inhi_spiking_t -last_inhi_spikes(n_id))/net.tau_z_f) + 1;
                        last_inhi_spikes(n_id) = inhi_spiking_t;
                     end
                 end
                 k = k+1;
             end
 
             hZ(:,1) = hZ(:,1).*exp(-double(t-last_output_spikes)/net.tau_z_r);
             hZ(:,2) = hZ(:,2).*exp(-double(t-last_output_spikes)/net.tau_z_f);
             hX(:,1) = hX(:,1).*exp(-double(t-last_input_spikes)/net.tau_x_r);
             hX(:,2) = hX(:,2).*exp(-double(t-last_input_spikes)/net.tau_x_f);
             hl(:,1) = hl(:,1).*exp(-double(t-last_inhi_spikes)/net.tau_z_r);
             hl(:,2) = hl(:,2).*exp(-double(t-last_inhi_spikes)/net.tau_z_f);
             
             d_hX = diff(hX,1,2);
             d_hZ = diff(hZ,1,2);
             d_hl = diff(hl,1,2);
             
             hX_all(:,j) = d_hX;
             hZ_all(:,j) = d_hZ;
             hl_all(:,j) = d_hl;
             
             last_input_spikes(:) = t;
             last_output_spikes(:) = t;
             last_inhi_spikes(:) = t;
            
              net.W = min(1,max(0.001,net.W));
              net.V = min(1,max(0.001,net.V));
             for n = 1:size(net.V,1)
                 net.V(n,n) = 0;
             end
             
             % update membrane potential
             U_ei =  net.EI*d_hl;
             U_ee = net.V*d_hZ+ net.V0;
             %U_v = U_ei + U_ee;
             U_w = net.w_temperature*net.W*d_hX;
             U = U_w + U_ee+U_ei;

             
             % compute spike propability
             %[P_t_v,A_v(j)] = wta_softmax( U_v );
             %[P_t_w,A_w(j)] = wta_softmax( U_w );
             P_t = zeros(net.num_neurons,1);
             [P_t,At] = wta_softmax2( U );
             P_t;
%              %P_t
%              pause;
%              At
%              pause;
%              [At;t]
%              pause;
%              net.At(:,j) = [At;t];
%              net.At(:,j)
%              pause;
             P(:,j) = P_t;
             
             % draw spike
             [Z_j,K] = wta_draw_k2(P_t,Z,j);
             Z(:,j) =Z_j(:);rec_spikes(:,j) = Z_j(:);
             a = max(a,size(K,1));
             

             % update inhibated membrane potential
             U_ie = net.IE*d_hZ;
             U_ii = net.II*d_hl;
             U_i = U_ie + U_ii;
             
             Pi(:,j) = U_i.*double(U_i>0);
             inhi_spikes(:,j) = double(random('Poisson',Pi(:,j))>0);
             mm = sum(inhi_spikes(:,max(1,j-3):max(1,j-1)),2);
             inhi_spikes(:,j) = (mm<1).*inhi_spikes(:,j);
             
             clear mm;
             
             % prepare synaptic weight updates (STDP)
             
             if ~isempty(K)
                 
                 for n_k = 1:size(K,1)
                  clear d_W_k;clear d_V_k; clear d_V0;
                  k1 = K(n_k);
                  net.num_o(k1) = net.num_o(k1)+1;
                  last_output_spikes(k1) = t;

%                   d_W_k1 = net.eta_W(k1,:).*(net.alpha_w*d_hX'-W_exp(k1,:))./max(net.eta_W(k1,:),W_exp(k1,:));
%                   d_V_k1 = net.eta_V(k1,:).*(net.alpha_v*d_hZ'-V_exp(k1,:))./max(net.eta_V(k1,:),V_exp(k1,:));
%                   d_V0_k1 = net.eta_0(k1,1)*(d_hZ(k1)-V0_exp(k1,1))/max(net.eta_0(k1,1),V0_exp(k1,1));
                  
                  %%%
                  W_d = 1-1./net.W(k1,:) + 1./(exp(net.W(k1,:))-1);
                  V_d = 1-1./max(0.00001,net.V(k1,:)) + 1./(exp(max(0.00001,net.V(k1,:)))-1);
                  V0_d = 1/(1+exp(-net.V0(k1,1)));
                  
                  d_W_k1 = net.eta_W(k1,:).*(net.alpha_w*d_hX'-W_d)./max(net.eta_W(k1,:),W_d);
                  d_V_k1 = net.eta_V(k1,:).*(net.alpha_v*d_hZ'-V_d)./max(net.eta_V(k1,:),V_d);
                  d_V0_k1 = net.eta_0(k1,1)*(d_hZ(k1)-V0_d)/max(net.eta_0(k1,1),V0_d);
                  %%%
                  %pause;
                  net.W(k1,:) = net.W(k1,:) + d_W_k1;
                  net.V(k1,:) = net.V(k1,:) + d_V_k1;
                  net.W(k1,:) = min(1,max(0.001,net.W(k1,:)));
                  net.V(k1,:) = min(1,max(0.001,net.V(k1,:)));
                  net.V(k1,k1) = 0;
                  net.V0(k1,1) = net.V0(k1,1) + d_V0_k1;
                  net.V0(k1,1);
                  %pause;
%                   W_exp(k1,:) = exp(double(net.W(k1,:)));
%                   V_exp(k1,:) = exp(double(net.V(k1,:)));
%                   V0_exp(k1,:) = exp(double(net.V0(k1,:)));
%                   W_exp(k,:) = exp( double( net.W(k,:) ) );
%                   V_exp(k,:) = exp( double( net.V(k,:) ) );
%                   V0_exp = exp( double( net.V0 ) );
                 end
                 
             end
%                    net.V0 = net.V0 + d_V0;
%               d_V0  = net.eta_0.*(Z_i-V0_exp)./max(net.eta_0,V0_exp);
                  %dW0 = net.W(k1,:)';dV0 = net.V(k1,:)';
                  
                  %dW0 = net.W(k,:)'*Z_j(k);
                  %dV0 = net.V(k,:)'*Z_j(k);
%                   dV0(k1) = 1;
%                   exp_W = 1./(exp(-dW0)+1);%1./(1 - 1./dW0+1./(exp(dW0)-1));
%                   exp_V = 1./(exp(-dV0)+1);%1./(1 - 1./dV0+1./(exp(dV0)-1));
%                    d_W_k =net.eta_W(k,:).*(net.alpha_w*d_hX'-W_exp(k,:))./max(net.eta_W(k,:),W_exp(k,:));%%%
%                    d_V_k  =net.eta_V(k,:).*(net.alpha_v*d_hZ'-V_exp(k,:))./max(net.eta_V(k,:),V_exp(k,:));%%%
%                    size(net.W')
%                    size(d_hZ)
%                    size(d_hX)
%                    size(exp_W)
%                    size(exp_V)
                   
                   
%                    d_W_k = Z_j(k1)*net.eta_W(k1,:)'.*(d_hX-exp_W);%./max(net.eta_W(k,:),W_exp(k,:));
%                    d_V_k  =Z_j(k1)*net.eta_V(k1,:)'.*(d_hZ-exp_V);%./max(net.eta_V(k,:),V_exp(k,:));
%                    d_W_k = d_W_k';d_V_k =  d_V_k';
%                    d_V_k(k1) = 0;
%                    size(d_W_k)
%                    size(net.W(k,:))
                   %d_V0   = net.eta_0(k,1).*(Z_j(k)-V0_exp(k))./max(net.eta_0(k,1),V0_exp(k));
%                    if net.update_on_spike
%                       net.W(k1,:) = min(1,max(0.01,(net.W(k1,:)+d_W_k)));
%                       net.V(k1,:) = min(1,max(0.01,(net.V(k1,:)+d_V_k)));
%                       net.V(k1,k1) = 0;
%                       %net.V0(k) = net.V0(k) + d_V0;
%                       W_exp(k1,:) = exp( double( net.W(k1,:) ) );
%                       V_exp(k1,:) = exp( double( net.V(k1,:) ) );
% %                      V0_exp(k) = exp( double( net.V0(k) ) );
% %                   else
% %                      net.d_W(k,:) = net.d_W(k,:) + d_W_k;
% %                      net.d_V(k,:) = net.d_V(k,:) + d_V_k;                
% %                      net.d_V0 = net.d_V0 + d_V0;
%                    end

%             
%             
% %             if net.use_variance_tracking
% %                 
% %                 SW_new(k,:) = SW_new(k,:) + net.eta_W(k,:).*((net.W(k,:)+d_W_k)-SW_new(k,:));
% %                 QW_new(k,:) = QW_new(k,:) + net.eta_W(k,:).*((net.W(k,:)+d_W_k).^2-QW_new(k,:));
% %                 
% %                 SV_new(k,:) = SV_new(k,:) + net.eta_V(k,:).*((net.V(k,:)+d_V_k)-SV_new(k,:));
% %                 QV_new(k,:) = QV_new(k,:) + net.eta_V(k,:).*((net.V(k,:)+d_V_k).^2-QV_new(k,:));
% %                 
% %                 S0_new = S0_new + net.eta_0.*((net.V0+d_V0)-S0_new);
% %                 Q0_new = Q0_new + net.eta_0.*((net.V0+d_V0).^2-Q0_new);
% %             end
%             
%             
         end
         a;
         max(P,2);
         mean(Z,2);
     catch
           fprintf('There has been an error, while sampling!\nExcluding run from training\n');
           file_name = sprintf('/tmp/error_data_%u_%04u.mat', net.iteration, round(9999*rand()) );
           the_error = lasterror();
           fprintf( '\n%s\n', the_error.message );
           fprintf( '  in %s on line %i\n\n', the_error.stack(1).name, the_error.stack(end).line );
           fprintf('saving workspace to: %s\n', file_name);
           save( file_name );
           net.R = -100000;
           fprintf('pausing 10 seconds...\n');
           pause(10);
           return;
    end
         inhi_spikes;
         Pi;
         %Z
%     catch
%         fprintf('There has been an error, while sampling!\nExcluding run from training\n');
%         file_name = sprintf('/tmp/error_data_%u_%04u.mat', net.iteration, round(9999*rand()) );
%         the_error = lasterror();
%         fprintf( '\n%s\n', the_error.message );
%         fprintf( '  in %s on line %i\n\n', the_error.stack(1).name, the_error.stack(end).line );
%         fprintf('saving workspace to: %s\n', file_name);
%         %save( file_name );
%         net.R = -100000;
%         fprintf('pausing 10 seconds...\n');
%         pause(10);
%         return;
%     end
    
%     if net.use_variance_tracking
%         net.SW_new = SW_new;
%         net.QW_new = QW_new;
% 
%         net.SV_new = SV_new;
%         net.QV_new = QV_new;
% 
%         net.S0_new = S0_new;
%         net.Q0_new = Q0_new;
%     end
    
    net.rec_spikes = rec_spikes(:,l:end);
    %net.rec_spikes(2,:) = net.rec_spikes(2,:)-t;
    %net.last_spike_t = net.last_spike_t - t;
    
    net.R = mean( net.At(1,:) );
    
    net.A_v = A_v;
    net.A_w = A_w;
    
%     if use_exact_iw
%         net.It = [ net.At(1,:)+A_v+A_w; net.At(2,:)  ];
%     else
%         net.It = net.At;
%     end
    
    net.hX = hX;
    net.hZ = hZ;
    net.hl = hl;
    net.hX_all = hX_all;
    net.hZ_all = hZ_all;
    net.hl_all =hl_all;
    net.spike_train = Z;

end
function binocular_brightnessperception(ex_path1,path,num_trials,T,stimulus,bottomgray,sti_size)
run snn1.7/snn_include;
snn_include( 'sem', 'hmmsem', 'plotting' );
default_params = default_options();
load(path);


s1 = [50,50];
s2 = [sti_size,sti_size];
bottomgray1 = (1-bottomgray) - bottomgray;
clear I;
for ii = 1:2
    clear I0;
    I0 = (bottomgray+(ii-1)*bottomgray1)*ones(s1);
    for m = ((s1(1)-s2(1))/2):(s2(1)+((s1(1)-s2(1))/2))
       for n = ((s1(2)-s2(2))/2):(s2(2)+((s1(2)-s2(2))/2))
           I0(m,n) = 0.5;
       end
    end
    figure;imshow(I0);
I(:,:,ii) = I0; 
end
%close all;
j = 0;
clear Irec;clear ave;
for ii = 1:2
    % j = j+1;
    clear name1;clear retinal_para_left;
    name1 = 'retinal_para_left.mat';
    retinal_para_left = load(name1);
    N_retinal = size(retinal_para_left.retinal_para.sample.sig_center,1);
    Irec0 = zeros(size(I0,1),size(I0,2));
    
    clear rate_retinal;
    for t = 1:1
    
            f1_l = I(:,:,ii);

            clear name2;clear retinal_para_left;
            name2 = 'retinal_para_left.mat';
            retinal_para_left =load(name2);
            N_retinal = size(retinal_para_left.retinal_para.sample.sig_center,1);
            
            for n_retinal = 1:N_retinal
            rate_retinal(n_retinal,1,t) = 0;
            center_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,1:2);
            surround_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,3:4);
            center_sig = retinal_para_left.retinal_para.sample.sig_center(n_retinal,1);
            center_sigma = [center_sig,0;0,center_sig];
            surround_sig = retinal_para_left.retinal_para.sample.sig_surround(n_retinal,1);
            surround_sigma = [surround_sig,0;0,surround_sig];
            k1 = retinal_para_left.retinal_para.sample.k(n_retinal,1);
            for n_x = 1:size(f1_l,2)
            for n_y = 1:size(f1_l,1)
                if f1_l(n_y,n_x)~=0
                p = mvnpdf([n_y,n_x],center_mean,center_sigma)-k1*mvnpdf([n_y,n_x],surround_mean,surround_sigma);
                rate_retinal(n_retinal,1,t) = rate_retinal(n_retinal,1,t)+p*f1_l(n_y,n_x);
                end
            end
            
            end
            
            end
            
            % rate_retinal(:,:,t) = 50*rate_retinal(:,:,t);
            rate_retinal = [rate_retinal;rate_retinal];

    end
L = size(test_data,2);
x_rate = zeros(size(rate_retinal,1),1);
Z_rate = zeros(size(test_data{1,1}.Zt,1),1);
for l = 1:L
    
    x4 = zeros(size(test_data{1,l}.x_range,2),T/2);
    x5 = zeros(size(test_data{1,l}.x_range,2),1);
    for ll = 1:size(test_data{1,l}.Xt,2)
        x5(test_data{1,l}.Xt(1,ll),(test_data{1,l}.Xt(2,ll)*1000)) = 1;
    end
    for ll1 = (T+(ii-1)*T+T/2+1):min(T+(ii-1)*T+T/2+T/2,size(x5,2))
        [ll1, ll1-T-(ii-1)*T-T/2]
        x4(:,ll1-T-(ii-1)*T-T/2) = x5(:,ll1);
    end
    
    %x_rate = zeros(size(x4,1),1);
    for t = 1:T/2
      for n = 1:size(x4,1)
              if x4(n,t) == 1
                x_rate(n,1) = x_rate(n,1)+1;
              end
      end
    end

    for t = (T+(ii-1)*T+T/2+1):(T+(ii-1)*T+T/2+T/2)
      for n = 1:size(test_data{1,l}.Zt,1)
              if test_data{1,l}.Zt(n,t) == 1
                Z_rate(n,1) = Z_rate(n,1)+1;
              end
      end
    end
end

for l = 1:1
    %clear Irec_l;clear Irec_r;
    clear Irec_retinal1;clear Irec_retinal_r;
    Irec1 = zeros(size(f1_l));
    %Irec_mon_r = zeros(size(f1_r));
    for t = 1:1
        for n = 1:size(x_rate,1)
                n_retinal = n-double(n>size(retinal_para_left.retinal_para.sample.ganglion_center,1))*size(retinal_para_left.retinal_para.sample.ganglion_center,1);
                Irec0 = zeros(size(f1_l));
                if (rate_retinal(n,1)>0)&&(x_rate(n)>0)
                    clear name2;clear retinal_para_left;
                    name2 = 'retinal_para_left.mat';
                    retinal_para_left = load(name2);
                    for n_x = 1:size(I(:,:,ii),2)
                     for n_y = 1:size(I(:,:,ii),1)
                        center_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,1:2);
                        surround_mean = retinal_para_left.retinal_para.sample.ganglion_center(n_retinal,3:4);
                        center_sig = retinal_para_left.retinal_para.sample.sig_center(n_retinal,1);
                        center_sigma = [center_sig,0;0,center_sig];
                        surround_sig = retinal_para_left.retinal_para.sample.sig_surround(n_retinal,1);
                        surround_sigma = [surround_sig,0;0,surround_sig];
                        k1 = retinal_para_left.retinal_para.sample.k(n_retinal,1);
                        Irec0(n_y,n_x) = rate_retinal(n,1) * (mvnpdf([n_y,n_x],center_mean,center_sigma)-k1*mvnpdf([n_y,n_x],surround_mean,surround_sigma));
                     end
                    end
                    Irec_retinal1(:,:) = Irec0(:,:)*x_rate(n);
                    for n2 = 1:net.num_neurons
                     if ( Z_rate(n2) > 0)
                      Irec1(:,:) = Irec1(:,:) + Irec_retinal1(:,:)*Z_rate(n2);
                     end
                    end
                end
        end
    end
Irec(:,:,ii) = Irec1;
end
end

Irec = Irec/L;

globle_recon = [];ave = [];
for  ii = 1:2
    a0 = Irec(:,:,ii);
    globle_recon(:,:,ii) = (a0 - min(a0(:)))/(max(a0(:))-min(a0(:)));
end
% figure;
% x = [0.5,2.5];
% plot(x,ave,'-o');
% xlim([0 3]);ylim([0 1.2*max(ave)]);ylabel('average brightness');

I0 = zeros(s1);
    for m = ((s1(1)-s2(1))/2):(s2(1)+((s1(1)-s2(1))/2))
        for n = ((s1(2)-s2(2))/2):(s2(2)+((s1(2)-s2(2))/2))
            I0(m,n) = 1;
        end
    end

sti_recon = [];
for  ii = 1:2
    sti_recon(:,:,ii) = globle_recon(:,:,ii).*I0;
end

for ii = 1:2
a3 = sti_recon(:,:,ii);
ave(ii) = mean(a3(:));
%figure;imshow(a3);
end

figure;
x = [0.5,2.5];
plot(x,ave,'-o');
xlim([0 3]);ylim([0 1.2*max(ave)]);ylabel('average brightness');

end
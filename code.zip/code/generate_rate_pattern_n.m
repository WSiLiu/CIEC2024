function pat = generate_rate_pattern_n( pattern, pattern_length, process )
% generate_rate_pattern
%
% Generates a rate patterns of a given length.
%
% 05.11.2011
% David Kappel
%
    %pattern = mean(pattern,2)
    spike_train = zeros(size(pattern,1),pattern_length*1000);
%     pattern_length
%     pause;
%     size(spike_train)
%     pause;
    if (nargin < 3)
        process = 'poisson';
    end
    
    switch process
        case 'poisson'
            if size(pattern,2) == 1
                for l = 1:pattern_length*1000
                  pattern(:,l) = pattern(:,1);
                end
            end
%             pattern_length
%             pattern_length/1000
            for t = 1:(pattern_length*1000)
                clear t1;clear b;
                t1 = max(1,t-3);
                b = sum(spike_train(:,t1:t),2);
                pattern(:,t) = (1-double(b>0)).*(pattern(:,t));
                spike_train(:,t) = double(poissrnd( pattern(:,t)/1000 )>0);
                spike_train(:,t) = (1-double(b>0)).*(spike_train(:,t));
            end

            l = 0;pat = zeros(2,1);
            for t = 1:1:size(spike_train,2)
                for n = 1:size(spike_train,1)
                    if spike_train(n,t) == 1
                        l = l+1;
                        pat(1,l) = n;pat(2,l) = t;
                    end
                end
            end
            pat(2,:) = pat(2,:)/1000;
%             pat
%             pause;
            
            %num_spikes = double(sum(spike_train,2))
%             size(num_spikes)
%             num_spikes
%             sum(double(num_spikes))
%             b = double(num_spikes(end));
%             b
            %doublesum(sum(poissrnd( pattern*pattern_length )>0))
% 
%             pat = zeros(2,sum(double(num_spikes)))
%             start_i = cumsum( [1; num_spikes(1:end-1)] );
% 
%             for i = 1:length(num_spikes);
% 
%                 pat( 1, start_i(i):(start_i(i)+num_spikes(i)-1) ) = i;
%                 pat( 2, start_i(i):(start_i(i)+num_spikes(i)-1) ) = ...
%                     pattern_length*rand( 1, num_spikes(i) );
%             end
% 
%             [v,idx] = sort( pat(2,:) );
%             pat = pat(:,idx);
            
        case 'regular'
            num_spikes = round( pattern*pattern_length );

            pat = zeros(2,sum(num_spikes),'single');

            start_i = cumsum( [1; num_spikes(1:end-1)] );

            for i = 1:length(num_spikes);

                pat( 1, start_i(i):(start_i(i)+num_spikes(i)-1) ) = i;
                pat( 2, start_i(i):(start_i(i)+num_spikes(i)-1) ) = pattern_length*(0:(1/num_spikes(i)):(1-(1/num_spikes(i))));
            end

            [v,idx] = sort( pat(2,:) );
            pat = pat(:,idx);
    end
end
